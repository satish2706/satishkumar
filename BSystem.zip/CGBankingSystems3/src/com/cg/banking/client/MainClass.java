package com.cg.banking.client;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


public class MainClass {

	public static void main(String[] args) {
	BankingServices services=new BankingServicesImpl();
	try {
		long accountNumber=services.openAccount("Savings", 4500.0f);
		System.out.println("Account number is: "+accountNumber);
		
		Account account=services.getAccountDetails(accountNumber);
		System.out.println(account);
	} catch (InvalidAmountException | InvalidAccountTypeException | BankingServiceDownException e) {
		
		e.printStackTrace();
	}

	}

}

package com.cg.banking.services;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transactions;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberexception;

public interface BankingServices {
	long openAccount(String accountType,float initBalance) throws InvalidAmountException,
	InvalidAccountTypeException,BankingServiceDownException;
	 
	float depositAmount(long accountNo,float amount)throws AccountNotFoundException,
	BankingServiceDownException,AccountBlockedException;

	float withdrawAmount(long accountNo,float amount,int pinNumber)throws InsufficientAmountException,
	AccountNotFoundException,InvalidPinNumberexception,BankingServiceDownException,AccountBlockedException;

	Account getAccountDetails(long accountNo)throws AccountNotFoundException,BankingServiceDownException;

	List<Account>getAllAccountDetails() throws BankingServiceDownException;

	List<Transactions>getAccountAllTransactions(long accountNo) throws BankingServiceDownException,
	AccountNotFoundException;
	
	public String accountStatus(long accountNo)
	throws BankingServiceDownException,AccountNotFoundException,AccountBlockedException;;
	

}

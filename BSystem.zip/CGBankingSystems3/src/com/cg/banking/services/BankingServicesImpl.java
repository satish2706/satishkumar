package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transactions;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDaoImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberexception;

public class BankingServicesImpl implements BankingServices{
private AccountDAO accountDao=new AccountDaoImpl();
	
	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServiceDownException {
		Account account=new Account(accountType,initBalance);
		account=accountDao.save(account);
		return account.getAccountNo();
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServiceDownException, AccountBlockedException {
		Account account=accountDao.findOne(accountNo);
		float finalAmount=account.getAccountBalance()+amount;
		account.setAccountBalance(finalAmount);
		return finalAmount;
	}
	

	@Override
	public String toString() {
		return "BankingServicesImpl [accountDao=" + accountDao + "]";
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberexception, BankingServiceDownException, AccountBlockedException {
		 Account account=accountDao.findOne(accountNo);
		 if(pinNumber==account.getPinNumber()) {
		 float finalAmount=account.getAccountBalance()-amount;
		 return finalAmount;}
		 else 
			 throw new InvalidPinNumberexception();
		
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServiceDownException {
		Account account=accountDao.findOne(accountNo);
		if(account==null)throw new AccountNotFoundException("Account number nahi hai hamare paas");
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServiceDownException {
		
		return accountDao.findAll();
	}

	@Override
	public List<Transactions> getAccountAllTransactions(long accountNo)
			throws BankingServiceDownException, AccountNotFoundException {
		
		return null;
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServiceDownException, AccountNotFoundException, AccountBlockedException {
		Account account=accountDao.findOne(accountNo);
		if(account==null)throw new AccountNotFoundException("Account number nahi hai hamare paas");
		return null;
	}

}

package com.cg.banking.exceptions;

public class InvalidPinNumberexception extends Exception {

}

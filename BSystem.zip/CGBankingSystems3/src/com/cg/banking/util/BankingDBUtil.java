package com.cg.banking.util;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Random;

import com.cg.banking.beans.Account;


public class BankingDBUtil {
	public static HashMap<Long,Account> account=new HashMap<>();
	static Random rand=new Random();
	private static int TRANSACTION_ID=1;
	public static int getTRANSACTION_ID() {
		return ++TRANSACTION_ID;
	}
	private static long ACCOUNT_NUMBER=2024017807;
	public static long getACCOUNT_NUMBER() {
		return ++ACCOUNT_NUMBER;
	}
	static private int n=9999-1000;
	private static long PIN_NUMBER=rand.nextInt()%n;
	public static  long PIN_NUMBER() {
		return  Math.abs(PIN_NUMBER);
	}
	public static LinkedList<Account> asso=new LinkedList<>();
}
